
// import 'package:flutter/material.dart';
// import 'package:ev_market/services/api_service.dart';

// class TwoWheelerForm extends StatefulWidget {
//   const TwoWheelerForm({super.key});

//   @override
//   State<TwoWheelerForm> createState() => _TwoWheelerFormState();
// }

// class _TwoWheelerFormState extends State<TwoWheelerForm> {
//   late Future<List<dynamic>> _twoWheelerData;

//   @override
//   void initState() {
//     super.initState();
//     _twoWheelerData = ApiService.fetchTwoWheelerData();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text("Two Wheeler List")),
//       body: FutureBuilder<List<dynamic>>(
//         future: _twoWheelerData,
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return const Center(child: CircularProgressIndicator());
//           }

//           if (snapshot.hasError) {
//             return Center(child: Text("Error: ${snapshot.error}"));
//           }

//           if (!snapshot.hasData || snapshot.data!.isEmpty) {
//             return const Center(child: Text("No data found"));
//           }

//           final data = snapshot.data!;

//           return SingleChildScrollView(
//             scrollDirection: Axis.horizontal,
//             child: DataTable(
//               columnSpacing: 20,
//               columns: const [
//                 DataColumn(label: Text('Name')),
//                 DataColumn(label: Text('Type')),
//                 DataColumn(label: Text('Brand')),
//                 DataColumn(label: Text('Price')),
//                 DataColumn(label: Text('Color')),
//                 DataColumn(label: Text('Battery')),
//                 DataColumn(label: Text('Upocming & Used')),
//                 DataColumn(label: Text('Speed')),
//               ],
//               rows: data.map((item) {
//                 return DataRow(
//                   cells: [
//                     DataCell(Text(item['vehicle_name'] ?? '')),
//                     DataCell(Text(item['type'] ?? '')),
//                     DataCell(Text(item['brand'] ?? '')),
//                     DataCell(Text(item['showroom_price'] ?? '')),
//                     DataCell(Text(item['color'] ?? '')),
//                     DataCell(Text(item['battery'] ?? '')),
//                     DataCell(Text(item['upcomming_and_used'] ?? '')),
//                     DataCell(Text(item['speed'] ?? '')),
//                   ],
//                 );
//               }).toList(),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }



// import 'package:flutter/material.dart';
// import 'package:ev_market/services/api_service.dart';

// class TwoWheelerForm extends StatefulWidget {
//   const TwoWheelerForm({super.key});

//   @override
//   State<TwoWheelerForm> createState() => _TwoWheelerFormState();
// }

// class _TwoWheelerFormState extends State<TwoWheelerForm> {
//   late Future<List<dynamic>> _twoWheelerData;

//   @override
//   void initState() {
//     super.initState();
//     _twoWheelerData = ApiService.fetchTwoWheelerData(); // API Call
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text("Two Wheeler List")),
//       body: FutureBuilder<List<dynamic>>(
//         future: _twoWheelerData,
//         builder: (context, snapshot) {
//           if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

//           final data = snapshot.data!;
//           return ListView.builder(
//             itemCount: data.length,
//             itemBuilder: (context, index) {
//               final item = data[index];
//               return ListTile(
//                 title: Text(item['vehicle_name']),
//                 subtitle: Text(item['brand']),
//               );
//             },
//           );
//         },
//       ),
//     );
//   }
// }



import 'package:flutter/material.dart';
import 'package:ev_market/services/api_service.dart';

class TwoWheelerForm extends StatefulWidget {
  const TwoWheelerForm({super.key});

  @override
  State<TwoWheelerForm> createState() => _TwoWheelerFormState();
}

class _TwoWheelerFormState extends State<TwoWheelerForm> {
  late Future<List<dynamic>> _twoWheelerData;

  @override
  void initState() {
    super.initState();
    _twoWheelerData = ApiService.fetchTwoWheelerData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Two Wheeler List")),
      body: FutureBuilder<List<dynamic>>(
        future: _twoWheelerData,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("No data found"));
          }

          final data = snapshot.data!;

          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columnSpacing: 20,
              columns: const [
                DataColumn(label: Text('Name')),
                DataColumn(label: Text('Type')),
                DataColumn(label: Text('Brand')),
                DataColumn(label: Text('Price')),
                DataColumn(label: Text('Color')),
                DataColumn(label: Text('Battery')),
                DataColumn(label: Text('Upocming & Used')),
                DataColumn(label: Text('Speed')),
              ],
              rows: data.map((item) {
                return DataRow(
                  cells: [
                    DataCell(Text(item['vehicle_name'] ?? '')),
                    DataCell(Text(item['type'] ?? '')),
                    DataCell(Text(item['brand'] ?? '')),
                    DataCell(Text(item['showroom_price'] ?? '')),
                    DataCell(Text(item['color'] ?? '')),
                    DataCell(Text(item['battery'] ?? '')),
                    DataCell(Text(item['upcomming_and_used'] ?? '')),
                    DataCell(Text(item['speed'] ?? '')),
                  ],
                );
              }).toList(),
            ),
          );
        },
      ),
    );
  }
}