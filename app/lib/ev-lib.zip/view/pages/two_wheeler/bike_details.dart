  import 'package:flutter/material.dart';

class Bike_Details extends StatefulWidget {
  const Bike_Details({super.key});

  @override
  State<Bike_Details> createState() => _Bike_DetailsState();
}

class _Bike_DetailsState extends State<Bike_Details> {

  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Text("bike details")
          ],
        ),
      ),
    );
  }
} 