// import 'package:ev_market/view/home_page.dart';
// import 'package:flutter/material.dart';

// class EV_Bike extends StatefulWidget {
//   const EV_Bike({super.key});

//   @override
//   State<EV_Bike> createState() => _EV_BikeState();
// }

// class _EV_BikeState extends State<EV_Bike> {
//   bool isChecked = false;

//   @override
//   Widget build(BuildContext context) {
//     // TODO: implement build
//     return Scaffold(
//       body: SingleChildScrollView(
//         padding: EdgeInsets.all(10),

//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.start,
//           children: [
//             Container(
//               width: double.infinity,
//               padding: EdgeInsets.fromLTRB(20, 50, 0, 20),
//               decoration: BoxDecoration(
//                 color: Colors.green,
//                 border: Border(
//                   bottom: BorderSide(
//                     style: BorderStyle.solid,
//                     color: Colors.red,
//                   ),
//                 ),
//               ),

//               child: Text.rich(
//                 TextSpan(
//                   children: [
//                     TextSpan(
//                       text: "E-Bike for Sale",
//                       style: TextStyle(
//                         color: const Color.fromARGB(255, 255, 255, 255),
//                         fontSize: 20,
//                         // decoration: TextDecoration.underline,
//                         // height: 15,
//                       ),
//                     ),
//                     TextSpan(
//                       text: "(Showing 1)",
//                       style: TextStyle(
//                         color: const Color.fromARGB(255, 255, 2, 2),
//                         fontSize: 20,
//                         fontWeight: FontWeight.bold,
//                         // decoration: TextDecoration.underline,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),

//             GridView.count(
//               crossAxisCount: 2,
//               padding: EdgeInsets.all(10),
//               crossAxisSpacing: 20,
//               mainAxisSpacing: 20,
//               shrinkWrap: true,
//               physics: NeverScrollableScrollPhysics(),
//               // 400 height chahiye, aur width ~180 hoti hai usually (half screen), so:
//               childAspectRatio: 180 / 400,
//               children: [
//                 // Container(color: Colors.red, child: Center(child: Text('Item 1'))),
//                 // Container(color: Colors.green, child: Center(child: Text('Item 2'))),
//                 // Container(color: Colors.blue, child: Center(child: Text('Item 3'))),
//                 // Container(color: Colors.orange, child: Center(child: Text('Item 4'))),
//                 // Container(color: Colors.purple, child: Center(child: Text('Item 5'))),
//                 Container(
//                   padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
//                   decoration: BoxDecoration(
//                     border: Border.all(width: 0, color: Colors.black45),
//                     borderRadius: BorderRadius.all(Radius.circular(10)),
//                     boxShadow: [
//                       BoxShadow(
//                         color: const Color.fromARGB(255, 70, 69, 69),
//                         offset: Offset(0, 0),
//                         blurRadius: 2,
//                         blurStyle: BlurStyle.outer,
//                       ),
//                     ],
//                   ),

//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       FadeInImage.assetNetwork(
//                         placeholder: "loading image",
//                         image:
//                             "https://cbvalueaddrealty.in/wp-content/uploads/2022/07/electric-vehicle.jpg",
//                         width: 180,
//                         height: 150,
//                         fit: BoxFit.cover,
//                       ),
//                       SizedBox(height: 10),
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,

//                         children: [
//                           Text("Hero Honda"),
//                           Icon(Icons.bike_scooter),
//                         ],
//                       ),
//                       Text.rich(
//                         TextSpan(
//                           children: [
//                             TextSpan(
//                               text: "Price ",
//                               style: TextStyle(fontSize: 15),
//                             ),
//                             WidgetSpan(
//                               child: Icon(
//                                 Icons.currency_rupee_rounded,
//                                 size: 15,
//                               ),
//                             ),
//                             TextSpan(
//                               text: "12,00,000",
//                               style: TextStyle(fontSize: 15),
//                             ),
//                           ],
//                         ),
//                       ),

//                       Container(
//                         padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
//                         child: Column(
//                           children: [
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Text("Motor \nPower"),
//                                 Text("Range"),
//                                 Text("Battery"),
//                               ],
//                             ),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Text(" 120Hz"),
//                                 Text("70km"),
//                                 Text("200v"),
//                               ],
//                             ),
//                           ],
//                         ),
//                       ),

//                       Column(
//                         children: [
//                           Row(
//                             children: [
//                               Checkbox(
//                                 value: isChecked,
//                                 onChanged: (bool? value) {
//                                   setState(() {
//                                     isChecked = value!;
//                                   });
//                                 },
//                               ),

//                               Text("Check it"),
//                             ],
//                           ),

//                           TextButton(
//                             onPressed: () {
//                               Navigator.push(
//                                 context,
//                                 MaterialPageRoute(
//                                   builder: (context) => Home_Page(),
//                                 ),
//                               );
//                             },
//                             child: Text("Get Details"),
//                             style: ButtonStyle(
//                               backgroundColor: WidgetStateProperty.all<Color>(
//                                 Colors.black,
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),

//                 Container(
//                   padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
//                   decoration: BoxDecoration(
//                     border: Border.all(width: 0, color: Colors.black45),
//                     borderRadius: BorderRadius.all(Radius.circular(10)),
//                     boxShadow: [
//                       BoxShadow(
//                         color: const Color.fromARGB(255, 70, 69, 69),
//                         offset: Offset(0, 0),
//                         blurRadius: 2,
//                         blurStyle: BlurStyle.outer,
//                       ),
//                     ],
//                   ),

//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       FadeInImage.assetNetwork(
//                         placeholder: "loading image",
//                         image:
//                             "https://cbvalueaddrealty.in/wp-content/uploads/2022/07/electric-vehicle.jpg",
//                         width: 180,
//                         height: 150,
//                         fit: BoxFit.cover,
//                       ),
//                       SizedBox(height: 10),
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,

//                         children: [
//                           Text("Hero Honda"),
//                           Icon(Icons.bike_scooter),
//                         ],
//                       ),
//                       Text.rich(
//                         TextSpan(
//                           children: [
//                             TextSpan(
//                               text: "Price ",
//                               style: TextStyle(fontSize: 15),
//                             ),
//                             WidgetSpan(
//                               child: Icon(
//                                 Icons.currency_rupee_rounded,
//                                 size: 15,
//                               ),
//                             ),
//                             TextSpan(
//                               text: "12,00,000",
//                               style: TextStyle(fontSize: 15),
//                             ),
//                           ],
//                         ),
//                       ),

//                       Container(
//                         padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
//                         child: Column(
//                           children: [
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Text("Motor \nPower"),
//                                 Text("Range"),
//                                 Text("Battery"),
//                               ],
//                             ),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Text(" 120Hz"),
//                                 Text("70km"),
//                                 Text("200v"),
//                               ],
//                             ),
//                           ],
//                         ),
//                       ),

//                       Column(
//                         children: [
//                           Row(
//                             children: [
//                               Checkbox(
//                                 value: isChecked,
//                                 onChanged: (bool? value) {
//                                   setState(() {
//                                     isChecked = value!;
//                                   });
//                                 },
//                               ),

//                               Text("Check it"),
//                             ],
//                           ),

//                           TextButton(
//                             onPressed: () {
//                               Navigator.push(
//                                 context,
//                                 MaterialPageRoute(
//                                   builder: (context) => Home_Page(),
//                                 ),
//                               );
//                             },
//                             child: Text("Get Details"),
//                             style: ButtonStyle(
//                               backgroundColor: WidgetStateProperty.all<Color>(
//                                 Colors.black,
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),                Container(
//                   padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
//                   decoration: BoxDecoration(
//                     border: Border.all(width: 0, color: Colors.black45),
//                     borderRadius: BorderRadius.all(Radius.circular(10)),
//                     boxShadow: [
//                       BoxShadow(
//                         color: const Color.fromARGB(255, 70, 69, 69),
//                         offset: Offset(0, 0),
//                         blurRadius: 2,
//                         blurStyle: BlurStyle.outer,
//                       ),
//                     ],
//                   ),

//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       FadeInImage.assetNetwork(
//                         placeholder: "loading image",
//                         image:
//                             "https://cbvalueaddrealty.in/wp-content/uploads/2022/07/electric-vehicle.jpg",
//                         width: 180,
//                         height: 150,
//                         fit: BoxFit.cover,
//                       ),
//                       SizedBox(height: 10),
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,

//                         children: [
//                           Text("Hero Honda"),
//                           Icon(Icons.bike_scooter),
//                         ],
//                       ),
//                       Text.rich(
//                         TextSpan(
//                           children: [
//                             TextSpan(
//                               text: "Price ",
//                               style: TextStyle(fontSize: 15),
//                             ),
//                             WidgetSpan(
//                               child: Icon(
//                                 Icons.currency_rupee_rounded,
//                                 size: 15,
//                               ),
//                             ),
//                             TextSpan(
//                               text: "12,00,000",
//                               style: TextStyle(fontSize: 15),
//                             ),
//                           ],
//                         ),
//                       ),

//                       Container(
//                         padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
//                         child: Column(
//                           children: [
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Text("Motor \nPower"),
//                                 Text("Range"),
//                                 Text("Battery"),
//                               ],
//                             ),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Text(" 120Hz"),
//                                 Text("70km"),
//                                 Text("200v"),
//                               ],
//                             ),
//                           ],
//                         ),
//                       ),

//                       Column(
//                         children: [
//                           Row(
//                             children: [
//                               Checkbox(
//                                 value: isChecked,
//                                 onChanged: (bool? value) {
//                                   setState(() {
//                                     isChecked = value!;
//                                   });
//                                 },
//                               ),

//                               Text("Check it"),
//                             ],
//                           ),

//                           TextButton(
//                             onPressed: () {
//                               Navigator.push(
//                                 context,
//                                 MaterialPageRoute(
//                                   builder: (context) => Home_Page(),
//                                 ),
//                               );
//                             },
//                             child: Text("Get Details"),
//                             style: ButtonStyle(
//                               backgroundColor: WidgetStateProperty.all<Color>(
//                                 Colors.black,
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),                Container(
//                   padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
//                   decoration: BoxDecoration(
//                     border: Border.all(width: 0, color: Colors.black45),
//                     borderRadius: BorderRadius.all(Radius.circular(10)),
//                     boxShadow: [
//                       BoxShadow(
//                         color: const Color.fromARGB(255, 70, 69, 69),
//                         offset: Offset(0, 0),
//                         blurRadius: 2,
//                         blurStyle: BlurStyle.outer,
//                       ),
//                     ],
//                   ),

//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       FadeInImage.assetNetwork(
//                         placeholder: "loading image",
//                         image:
//                             "https://cbvalueaddrealty.in/wp-content/uploads/2022/07/electric-vehicle.jpg",
//                         width: 180,
//                         height: 150,
//                         fit: BoxFit.cover,
//                       ),
//                       SizedBox(height: 10),
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,

//                         children: [
//                           Text("Hero Honda"),
//                           Icon(Icons.bike_scooter),
//                         ],
//                       ),
//                       Text.rich(
//                         TextSpan(
//                           children: [
//                             TextSpan(
//                               text: "Price ",
//                               style: TextStyle(fontSize: 15),
//                             ),
//                             WidgetSpan(
//                               child: Icon(
//                                 Icons.currency_rupee_rounded,
//                                 size: 15,
//                               ),
//                             ),
//                             TextSpan(
//                               text: "12,00,000",
//                               style: TextStyle(fontSize: 15),
//                             ),
//                           ],
//                         ),
//                       ),

//                       Container(
//                         padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
//                         child: Column(
//                           children: [
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Text("Motor \nPower"),
//                                 Text("Range"),
//                                 Text("Battery"),
//                               ],
//                             ),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Text(" 120Hz"),
//                                 Text("70km"),
//                                 Text("200v"),
//                               ],
//                             ),
//                           ],
//                         ),
//                       ),

//                       Column(
//                         children: [
//                           Row(
//                             children: [
//                               Checkbox(
//                                 value: isChecked,
//                                 onChanged: (bool? value) {
//                                   setState(() {
//                                     isChecked = value!;
//                                   });
//                                 },
//                               ),

//                               Text("Check it"),
//                             ],
//                           ),

//                           TextButton(
//                             onPressed: () {
//                               Navigator.push(
//                                 context,
//                                 MaterialPageRoute(
//                                   builder: (context) => Home_Page(),
//                                 ),
//                               );
//                             },
//                             child: Text("Get Details"),
//                             style: ButtonStyle(
//                               backgroundColor: WidgetStateProperty.all<Color>(
//                                 Colors.black,
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),

//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// Container(
//   width: 200,
//   height: 400,
//   padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
//   decoration: BoxDecoration(
//     border: Border.all(width: 0, color: Colors.black45),
//     borderRadius: BorderRadius.all(Radius.circular(10)),
//     boxShadow: [
//       BoxShadow(
//         color: const Color.fromARGB(255, 70, 69, 69),
//         offset: Offset(0, 0),
//         blurRadius: 2,
//         blurStyle: BlurStyle.outer
//       )
//     ]
//   ),

//   child: Column(
//     crossAxisAlignment: CrossAxisAlignment.start,
//     children: [
//       FadeInImage.assetNetwork(
//         placeholder: "loading image",
//         image:
//             "https://cbvalueaddrealty.in/wp-content/uploads/2022/07/electric-vehicle.jpg",
//         width: 180,
//         height: 150,
//         fit: BoxFit.cover,
//       ),
//       SizedBox(height: 10),
//       Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,

//         children: [Text("Hero Honda"), Icon(Icons.bike_scooter)],
//       ),
//       Text.rich(
//         TextSpan(
//           children: [
//             TextSpan(
//               text: "Price ",
//               style: TextStyle(fontSize: 15),
//             ),
//             WidgetSpan(
//               child: Icon(Icons.currency_rupee_rounded, size: 15),
//             ),
//             TextSpan(
//               text: "12,00,000",
//               style: TextStyle(fontSize: 15),
//             ),
//           ],
//         ),
//       ),

//       Container(
//         padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
//         child: Column(
//           children: [
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text("Motor \nPower"),
//                 Text("Range"),
//                 Text("Battery"),
//               ],
//             ),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text(" 120Hz"),
//                 Text("70km"),
//                 Text("200v"),
//               ],
//             ),
//           ],
//         ),
//       ),

//       Column(
//         children: [
//           Row(
//             children: [
//               Checkbox(
//                 value: isChecked,
//                 onChanged: (bool? value) {
//                   setState(() {
//                     isChecked = value!;
//                   });
//                 },
//               ),

//               Text("Check it"),
//             ],
//           ),

//           TextButton(
//             onPressed: () {
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => Home_Page(),
//                 ),
//               );
//             },
//             child: Text("Get Details"),
//             style: ButtonStyle(
//               backgroundColor: WidgetStateProperty.all<Color>(
//                 Colors.black,
//               ),
//             ),
//           ),
//         ],
//       ),
//     ],
//   ),
// ),

// import 'package:ev_market/view/home_page.dart';
import 'package:ev_market/view/pages/two_wheeler/bike_details.dart';
import 'package:flutter/material.dart';

class EV_Bike extends StatefulWidget {
  const EV_Bike({super.key});

  @override
  State<EV_Bike> createState() => _EV_BikeState();
}

class _EV_BikeState extends State<EV_Bike> {
  bool isChecked = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Section (fixed on top)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  vertical: 24,
                  horizontal: 20,
                ),
                decoration: BoxDecoration(
                  color: Colors.green.shade700,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.green.shade900.withOpacity(0.6),
                      blurRadius: 8,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: RichText(
                  text: TextSpan(
                    children: [
                      const TextSpan(
                        text: "E-Bike for Sale ",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      TextSpan(
                        text: "(Showing 5)",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                          color: Colors.red.shade300,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // GridView as a shrink-wrapped widget, no scrolling of its own
              GridView.builder(
                physics:
                    const NeverScrollableScrollPhysics(), // Disable GridView scrolling
                shrinkWrap: true, // Let GridView take only the space it needs
                padding: const EdgeInsets.all(10),
                itemCount: 4,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 18,
                  mainAxisSpacing: 18,
                  mainAxisExtent: 420,
                ),
                itemBuilder: (context, index) {
                  return _buildBikeCard();
                },
              ),

              const SizedBox(height: 20),

              // Extra widgets below GridView - these will scroll with the page
              Text("data"),
              Text("data"),
              Text("data"),
              Text("data"),
              Text("data"),
              Text("data"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBikeCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade400.withOpacity(0.3),
            offset: const Offset(0, 4),
            blurRadius: 8,
          ),
        ],
      ),
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image with rounded corners
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: FadeInImage.assetNetwork(
              placeholder:
                  'assets/loading.gif', // Update this path or replace with SizedBox()
              image:
                  "https://cbvalueaddrealty.in/wp-content/uploads/2022/07/electric-vehicle.jpg",
              width: double.infinity,
              height: 150,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 12),

          // Title + Icon row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                "Hero Honda",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
              Icon(Icons.bike_scooter, color: Colors.green.shade700, size: 24),
            ],
          ),
          const SizedBox(height: 8),

          // Price row
          RichText(
            text: TextSpan(
              children: [
                const TextSpan(
                  text: "Price: ",
                  style: TextStyle(color: Colors.black87, fontSize: 16),
                ),
                WidgetSpan(
                  child: Icon(
                    Icons.currency_rupee_rounded,
                    size: 18,
                    color: Colors.black87,
                  ),
                ),
                const TextSpan(
                  text: " 12,00,000",
                  style: TextStyle(color: Colors.black87, fontSize: 16),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Specs
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: Column(
              children: const [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Motor\nPower",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    Text(
                      "Range",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    Text(
                      "Battery",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("120Hz", textAlign: TextAlign.center),
                    Text("70km", textAlign: TextAlign.center),
                    Text("200v", textAlign: TextAlign.center),
                  ],
                ),
              ],
            ),
          ),
          const Spacer(),

          // Checkbox above button
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Checkbox(
                    value: isChecked,
                    onChanged: (bool? value) {
                      setState(() {
                        isChecked = value ?? false;
                      });
                    },
                    activeColor: Colors.green.shade700,
                  ),
                  const Text("Check it"),
                ],
              ),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green.shade700,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => Bike_Details()),
                    );
                  },
                  child: const Text(
                    "Get Details",
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
