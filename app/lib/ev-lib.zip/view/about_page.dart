import 'package:flutter/material.dart';

class About_Page extends StatelessWidget {
  const About_Page({super.key});

  @override
 Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("EV Market")),
      body: Column(
        children: [
          _top_screen_image(), // 👈 custom function use kiya
          const SizedBox(height: 120),
          const Text("Welcome to EV Market"),
        ],
      ),
    );
  }

  // 👇 Yeh tumhara custom widget function
  Widget _top_screen_image() {
    return Text("data");
  }
}