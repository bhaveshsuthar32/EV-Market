import 'package:flutter/material.dart';

class Contact_Page extends StatelessWidget {
  const Contact_Page({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text("hello contact page"),
    );
  }
}