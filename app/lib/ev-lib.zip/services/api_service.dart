// import 'dart:convert';
// import 'dart:nativewrappers/_internal/vm/lib/math_patch.dart';
// import 'package:http/http.dart' as http;

// class ApiService {
//   static const String baseUrl = 'http://localhost:4000';
  
//   static Future<Map<String, dynamic>> fetchUerData() async{
//     try {
//       final response = await http.get(Uri.parse('$baseUrl/api/user'));

//       if (response.statusCode == 200) {
//         return jsonDecode(response.body);
//       } else {
//         throw Exception("Failed to load data");
//       }
//     } catch (e) {
//       throw Exception("Error: $e");
//     }
//   }
// }


  // import 'dart:convert';
  // import 'package:http/http.dart' as http;

  // class ApiService {
  //   // static const String baseUrl = 'http://10.56.77.54:4000'; // ✅ Use your PC IP here
  //   static const String baseUrl = 'https://ev-market-server.vercel.app';


    // static Future<List<dynamic>> fetchTwoWheelerData() async {
    //   try {
    //     final response = await http.get(Uri.parse('$baseUrl/getBikeData'));

    //     if (response.statusCode == 200) {
    //       final decoded = jsonDecode(response.body);
    //       return decoded['data'];
    //     } else {
    //       throw Exception("Failed to load two-wheeler data");
    //     }
    //   } catch (e) {
    //     throw Exception("Error: $e");
    //   }
    // }


    
// static Future<List<dynamic>> fetchTwoWheelerData() async {
//   try {
//     final response = await http.get(Uri.parse('$baseUrl/getBikeData'));

//     if (response.statusCode == 200) {
//       final decoded = jsonDecode(response.body);
//       if (decoded is List) {
//         return decoded;
//       } else if (decoded is Map && decoded['data'] is List) {
//         return decoded['data'];
//       } else {
//         throw Exception("Unexpected response format: $decoded");
//       }
//     } else {
//       throw Exception("Failed to load two-wheeler data");
//     }
//   } catch (e) {
//     throw Exception("Error: $e");
//   }
// }

//   }




import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // Aapka backend URL (Vercel)
  static const String baseUrl = 'https://ev-market-server.vercel.app';

  static Future<List<dynamic>> fetchTwoWheelerData() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/getBikeData'));

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);

        if (decoded is List) {
          return decoded; // API direct list return kar rahi hai
        } else {
          throw Exception("Unexpected response format: $decoded");
        }
      } else {
        throw Exception("Failed to load two-wheeler data");
      }
    } catch (e) {
      throw Exception("Error fetching data: $e");
    }
  }
}


